-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg120.eigbox.net
-- Generation Time: Jun 20, 2018 at 05:16 PM
-- Server version: 5.6.37
-- PHP Version: 4.4.9
-- 
-- Database: `cmeier`
-- 
CREATE DATABASE `cmeier` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cmeier`;

-- --------------------------------------------------------

-- 
-- Table structure for table `Customers`
-- 

CREATE TABLE `Customers` (
  `CustID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text NOT NULL,
  `Address` text NOT NULL,
  `Phone` int(11) NOT NULL,
  `Coordinates` text NOT NULL,
  PRIMARY KEY (`CustID`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

-- 
-- Dumping data for table `Customers`
-- 

INSERT INTO `Customers` VALUES (39, 'Testbo', '124 Oriole Dr, St Charles, MO 63301', 2147483647, '(38.8008275, -90.50752109999996)');
INSERT INTO `Customers` VALUES (40, 'yeye', '2855 Veterans Memorial Pkwy, St Charles, MO 63303', 2147483647, '(38.7858975, -90.53415860000001)');
INSERT INTO `Customers` VALUES (41, 'Tootsy', '301 Sunnydale Dr St Charles, MO 63301', 12412124, '(38.7902408, -90.5333445)');
INSERT INTO `Customers` VALUES (42, 'Gordon ', '3601 Droste Rd St Charles, MO 63301', 3333333, '(38.801711, -90.533344)');
INSERT INTO `Customers` VALUES (43, 'Kyle', '1701 Veterans Memorial Pkwy St Charles, MO 63303', 7654321, '(38.773891, -90.510403)');
INSERT INTO `Customers` VALUES (44, 'Tam', '1365 S 5th St St Charles, MO 63301', 3333333, '(38.7708953, -90.49727530000001)');
INSERT INTO `Customers` VALUES (45, 'Tayne', '2805 Elm St St Charles, MO 63301', 5435436, '(38.798746, -90.50253650000002)');
INSERT INTO `Customers` VALUES (46, 'Burger', '3100 Droste Rd St Charles, MO 63301', 4324235, '(38.797191, -90.525354)');
INSERT INTO `Customers` VALUES (47, 'Burt', '2660 Zumbehl Rd St Charles, MO 63301', 4324235, '(38.7983948, -90.53246079999997)');
INSERT INTO `Customers` VALUES (48, 'Bobaet', '1365 S 5th St St Charles, MO 63301', 12345674, '(38.7708953, -90.49727530000001)');
INSERT INTO `Customers` VALUES (49, 'secName', '3801 Mueller Rd St Charles, MO 63301', 0, '(38.828241, -90.51163700000001)');
INSERT INTO `Customers` VALUES (50, 'Bob', '400 N 6th St St Charles, MO 63301', 1232345, '(38.7862139, -90.48645540000001)');
INSERT INTO `Customers` VALUES (51, 'Testbo', '200 S Main St St Charles, MO 63301', 2147483647, '(38.7800218, -90.48185920000003)');
INSERT INTO `Customers` VALUES (52, 'yeye', '124 Oriole Dr, St Charles, MO 63301', 2147483647, '(38.8008275, -90.50752109999996)');
INSERT INTO `Customers` VALUES (53, 'Fuff', '3601 Droste Rd St Charles, MO 63301', 2147483647, '(38.801711, -90.533344)');
INSERT INTO `Customers` VALUES (54, 'asdasd', '3601 Droste Rd St Charles, MO 63301', 2147483647, '(38.801711, -90.533344)');
INSERT INTO `Customers` VALUES (55, 'reretee', '3601 Droste Rd St Charles, MO 63301', 2147483647, '(38.801711, -90.533344)');
INSERT INTO `Customers` VALUES (56, 'rereteasde', '3601 Droste Rd St Charles, MO 63301', 2147483647, '(38.801711, -90.533344)');
INSERT INTO `Customers` VALUES (57, 'nootlfdes', '124 Oriole Dr, St Charles, MO 63301', 2345245, '(38.8008275, -90.50752109999996)');
INSERT INTO `Customers` VALUES (58, 'Barcus Jackson', '3601 Mueller Rd St Charles, MO 63301', 2147483647, '(38.8198473, -90.5000556)');

-- --------------------------------------------------------

-- 
-- Table structure for table `Drivers`
-- 

CREATE TABLE `Drivers` (
  `DriverID` int(11) NOT NULL AUTO_INCREMENT,
  `First` text NOT NULL,
  `Last` text NOT NULL,
  `Nick` text NOT NULL,
  `ClockedIn` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`DriverID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

-- 
-- Dumping data for table `Drivers`
-- 

INSERT INTO `Drivers` VALUES (2, 'Chris', 'Meier', 'Chris', 1);
INSERT INTO `Drivers` VALUES (3, 'Bob', 'Jones', 'Bobby', 1);
INSERT INTO `Drivers` VALUES (4, 'Jack', 'Adams', 'Jadams', 1);
INSERT INTO `Drivers` VALUES (5, 'Katie', 'Spies', 'Bug', 0);
INSERT INTO `Drivers` VALUES (6, 'Francis', 'Ballard', 'Fireball', 0);
INSERT INTO `Drivers` VALUES (7, 'Shoe', 'Guy', 'Sneakers', 0);
INSERT INTO `Drivers` VALUES (8, 'fasdf', 'asdf', 'asdfas', 0);
INSERT INTO `Drivers` VALUES (9, 'secFirst', 'secLast', 'secNick', 1);
INSERT INTO `Drivers` VALUES (10, 'hashboy', 'hasher', 'hashed', 0);
INSERT INTO `Drivers` VALUES (11, 'hashley', 'hashington', 'hashley', 0);
INSERT INTO `Drivers` VALUES (12, 'Bill', 'Smith', 'BillBob', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `GrandOrders`
-- 

CREATE TABLE `GrandOrders` (
  `GrandID` int(11) NOT NULL AUTO_INCREMENT,
  `TicketID` int(11) NOT NULL,
  `Date` text NOT NULL,
  `Status` text NOT NULL,
  `Settled` text NOT NULL,
  `DriverID` int(11) NOT NULL,
  `CustID` int(11) DEFAULT NULL,
  PRIMARY KEY (`GrandID`),
  KEY `CustID` (`CustID`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

-- 
-- Dumping data for table `GrandOrders`
-- 

INSERT INTO `GrandOrders` VALUES (27, 1, '2018-03-22 20:55:14', 'CLOSED', 'YES', 3, 39);
INSERT INTO `GrandOrders` VALUES (28, 2, '2018-03-22 20:56:30', 'CLOSED', 'YES', 2, 40);
INSERT INTO `GrandOrders` VALUES (29, 3, '2018-04-09 14:45:47', 'CLOSED', 'YES', 2, 41);
INSERT INTO `GrandOrders` VALUES (30, 4, '2018-04-09 15:34:24', 'OPEN', 'NO', 0, 42);
INSERT INTO `GrandOrders` VALUES (31, 5, '2018-04-15 17:05:01', 'OPEN', 'NO', 0, 43);
INSERT INTO `GrandOrders` VALUES (32, 6, '2018-04-23 21:04:13', 'OPEN', 'NO', 0, 44);
INSERT INTO `GrandOrders` VALUES (33, 7, '2018-04-23 21:07:55', 'CLOSED', 'NO', 2, 45);
INSERT INTO `GrandOrders` VALUES (34, 8, '2018-04-23 21:09:23', 'CLOSED', 'NO', 2, 46);
INSERT INTO `GrandOrders` VALUES (35, 9, '2018-04-23 21:14:14', 'CLOSED', 'NO', 2, 47);
INSERT INTO `GrandOrders` VALUES (36, 10, '2018-04-23 21:29:22', 'OPEN', 'NO', 0, 48);
INSERT INTO `GrandOrders` VALUES (38, 11, '2018-05-14 18:16:20', 'OPEN', 'NO', 0, 56);
INSERT INTO `GrandOrders` VALUES (39, 12, '2018-05-14 18:17:55', 'OPEN', 'NO', 0, 57);
INSERT INTO `GrandOrders` VALUES (40, 13, '2018-05-14 20:25:56', 'CLOSED', 'NO', 2, 58);

-- --------------------------------------------------------

-- 
-- Table structure for table `Login`
-- 

CREATE TABLE `Login` (
  `UserID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` text NOT NULL,
  `Password` text NOT NULL,
  `Manager` tinyint(1) NOT NULL DEFAULT '0',
  `DriverID` int(11) NOT NULL,
  PRIMARY KEY (`UserID`),
  KEY `DriverID` (`DriverID`)
) ENGINE=InnoDB AUTO_INCREMENT=1250 DEFAULT CHARSET=latin1 AUTO_INCREMENT=1250 ;

-- 
-- Dumping data for table `Login`
-- 

INSERT INTO `Login` VALUES (1237, 'user', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 2);
INSERT INTO `Login` VALUES (1238, 'kspies', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 5);
INSERT INTO `Login` VALUES (1239, 'taco', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 2);
INSERT INTO `Login` VALUES (1240, 'bobber', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 3);
INSERT INTO `Login` VALUES (1241, 'jackattack', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 4);
INSERT INTO `Login` VALUES (1243, 'fire', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 6);
INSERT INTO `Login` VALUES (1244, 'foot', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 7);
INSERT INTO `Login` VALUES (1246, 'secUser', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 9);
INSERT INTO `Login` VALUES (1247, 'hash', '$2y$10$hQNmdbu58pNwiqHOLItqJuW2fcQ9OK1ZcJpoMQ9JLF/bbjePkLJS2', 0, 10);
INSERT INTO `Login` VALUES (1248, 'hash2', '$2y$10$2oiOAp/33XrlKzMjbLt8a.nKoSNxGltA7mGEQ.4QzkvMlIoPeAoAu', 0, 11);
INSERT INTO `Login` VALUES (1249, 'billysmith', '$2y$10$oiB00cK9k6c/VbKLMr9V4OjsC19qcFu6ssdukDrMGZn784bs0gCVm', 0, 12);

-- --------------------------------------------------------

-- 
-- Table structure for table `Orders`
-- 

CREATE TABLE `Orders` (
  `GrandID` int(11) NOT NULL,
  `PizzaID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Size` int(11) NOT NULL,
  PRIMARY KEY (`GrandID`,`PizzaID`,`Size`),
  KEY `PizzaID` (`PizzaID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `Orders`
-- 

INSERT INTO `Orders` VALUES (0, 2, 1, 10);
INSERT INTO `Orders` VALUES (0, 3, 2, 10);
INSERT INTO `Orders` VALUES (27, 2, 1, 10);
INSERT INTO `Orders` VALUES (27, 3, 3, 16);
INSERT INTO `Orders` VALUES (28, 1, 1, 10);
INSERT INTO `Orders` VALUES (28, 1, 1, 14);
INSERT INTO `Orders` VALUES (28, 2, 1, 10);
INSERT INTO `Orders` VALUES (29, 1, 2, 16);
INSERT INTO `Orders` VALUES (29, 2, 1, 10);
INSERT INTO `Orders` VALUES (30, 3, 7, 10);
INSERT INTO `Orders` VALUES (31, 2, 1, 10);
INSERT INTO `Orders` VALUES (31, 3, 3, 12);
INSERT INTO `Orders` VALUES (32, 2, 1, 10);
INSERT INTO `Orders` VALUES (33, 3, 1, 12);
INSERT INTO `Orders` VALUES (34, 2, 2, 10);
INSERT INTO `Orders` VALUES (35, 2, 2, 10);
INSERT INTO `Orders` VALUES (36, 2, 1, 10);
INSERT INTO `Orders` VALUES (38, 2, 1, 10);
INSERT INTO `Orders` VALUES (39, 2, 1, 10);
INSERT INTO `Orders` VALUES (40, 2, 2, 10);
INSERT INTO `Orders` VALUES (40, 3, 1, 12);

-- --------------------------------------------------------

-- 
-- Table structure for table `Pizzas`
-- 

CREATE TABLE `Pizzas` (
  `PizzaID` int(11) NOT NULL,
  `Type` text NOT NULL,
  `Base_Price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`PizzaID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- 
-- Dumping data for table `Pizzas`
-- 

INSERT INTO `Pizzas` VALUES (1, 'Pepperoni', 9.00);
INSERT INTO `Pizzas` VALUES (2, 'Cheese', 8.50);
INSERT INTO `Pizzas` VALUES (3, 'Deluxe', 10.00);

-- 
-- Constraints for dumped tables
-- 

-- 
-- Constraints for table `GrandOrders`
-- 
ALTER TABLE `GrandOrders`
  ADD CONSTRAINT `GrandOrders_ibfk_1` FOREIGN KEY (`CustID`) REFERENCES `Customers` (`CustID`);

-- 
-- Constraints for table `Login`
-- 
ALTER TABLE `Login`
  ADD CONSTRAINT `Login_ibfk_1` FOREIGN KEY (`DriverID`) REFERENCES `Drivers` (`DriverID`);
